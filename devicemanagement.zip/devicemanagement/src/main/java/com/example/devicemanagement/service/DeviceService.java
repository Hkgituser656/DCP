// DeviceService.java
package com.example.devicemanagement.service;

import com.example.devicemanagement.entity.Device;
import com.example.devicemanagement.entity.Owner;
import com.example.devicemanagement.repository.DeviceRepository;
import com.example.devicemanagement.repository.OwnerRepository;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class DeviceService {
    private final DeviceRepository deviceRepo;
    private final OwnerRepository ownerRepo;

    public DeviceService(DeviceRepository deviceRepo, OwnerRepository ownerRepo) {
        this.deviceRepo = deviceRepo;
        this.ownerRepo = ownerRepo;
    }

    public String registerDevice(Device device) {
        if (deviceRepo.findBySerialNumber(device.getSerialNumber()).isPresent()) {
            return "Device with this serial number already exists";
        }
        deviceRepo.save(device);
        return "Device registered successfully";
    }

    public String assignOwner(Long deviceId, Owner owner) {
        Optional<Device> deviceOpt = deviceRepo.findById(deviceId);
        if (deviceOpt.isEmpty()) return "Device not found";

        Device device = deviceOpt.get();
        ownerRepo.save(owner);  // Save owner first (generates ownerId)
        device.setOwner(owner);
        deviceRepo.save(device);

        return "Owner assigned successfully";
    }


    public String updateStatus(Long deviceId, Device.Status status) {
        Optional<Device> deviceOpt = deviceRepo.findById(deviceId);
        if (deviceOpt.isEmpty()) return "Device not found";

        Device device = deviceOpt.get();
        device.setStatus(status);
        deviceRepo.save(device);
        return "Device status updated successfully";
    }
}
