package com.example.devicemanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Devices")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Device {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long deviceId;

    @Column(unique = true, nullable = false)
    private String serialNumber;

    private String deviceName;

    @Enumerated(EnumType.STRING)
    private Status status = Status.active;

    // Link to Owner - Many devices can belong to one owner
    @ManyToOne
    @JoinColumn(name = "owner_id") // FK column in Devices table
    private Owner owner;

    @Column(name = "created_at", updatable = false, insertable = false)
    private String createdAt;

    @Column(name = "updated_at", insertable = false)
    private String updatedAt;

    public enum Status {
        active,
        inactive,
        soft_deleted
    }
}
