// OwnerRepository.java
package com.example.devicemanagement.repository;

import com.example.devicemanagement.entity.Owner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OwnerRepository extends JpaRepository<Owner, Long> {}
