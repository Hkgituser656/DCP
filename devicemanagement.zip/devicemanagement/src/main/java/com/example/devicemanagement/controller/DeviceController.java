// DeviceController.java
package com.example.devicemanagement.controller;

import com.example.devicemanagement.entity.Device;
import com.example.devicemanagement.entity.Owner;
import com.example.devicemanagement.service.DeviceService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/devices")
@CrossOrigin("*")
public class DeviceController {
    private final DeviceService deviceService;

    public DeviceController(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @PostMapping("/register")
    public String registerDevice(@RequestBody Device device) {
        return deviceService.registerDevice(device);
    }

    @PostMapping("/{deviceId}/assign-owner")
    public String assignOwner(@PathVariable Long deviceId, @RequestBody Owner owner) {
        return deviceService.assignOwner(deviceId, owner);
    }

    @PutMapping("/{deviceId}/update-status")
    public String updateStatus(@PathVariable Long deviceId, @RequestParam Device.Status status) {
        return deviceService.updateStatus(deviceId, status);
    }
}
