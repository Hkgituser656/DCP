// ITAdminRepository.java
package com.example.devicemanagement.repository;

import com.example.devicemanagement.entity.ITAdministrator;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ITAdminRepository extends JpaRepository<ITAdministrator, Long> {}
