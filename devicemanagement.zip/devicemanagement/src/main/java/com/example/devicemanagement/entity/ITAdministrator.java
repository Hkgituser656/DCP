// ITAdministrator.java
package com.example.devicemanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ITAdministrators")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ITAdministrator {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long adminId;

    private String name;
    private String email;
    private String passwordHash;

    @Column(name = "created_at", updatable = false, insertable = false)
    private String createdAt;
}
